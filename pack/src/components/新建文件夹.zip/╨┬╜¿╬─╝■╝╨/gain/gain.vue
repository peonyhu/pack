<template>
  <div>
    <div class="m-index" ref="index1">
      {{this.offsetHeight}}
      {{this.offsetWidth}}
      <div class="m-fans"></div>
      <div class="m-con">
        <div class="m-home">
          <span class="m-gain"><span class="m-des mt196">好友<em class="c_fff445">FFF</em>向您赠送</span></span>
          <div class="m-con"><span class="m-money"></span></div>
          <span class="m-des">无门槛现金红包</span>
          <div class="m-verify mt28">
            <div class="m-base clearfix">
              <input type="text" v-model="oMobileVal" placeholder="请输入您的手机号码！" id="mobile" class="whole" @focus="mobileFocus" @blur="mobileBlur" />
              <p id="mobile_prompt" class="xs_error">{{oMobileError}}</p>
              <span></span>
            </div>
            <div class="m-con m-bn">
              <a href="javascript:;" class="c_fd5600 gainbn" id="j-gain" @click="gain">立即领取</a>
            </div>
            <p class="m-frid"><span class="j-friend" @click="friendForward">转给其他好友  >></span><span class="ml30 j-rule" @click="rule">活动规则  >></span></p>
          </div>
        </div>
      </div>
    </div>
    <component v-bind:item="special" v-bind:is="currentView" v-if="this.show">
      <!-- 组件在 vm.currentview 变化时改变！ -->
    </component>
    <register></register>
    <alertmsg v-show="alertIsShow" ref="alertmsg" v-on:myHeight="toAlertHeight" v-on:myWidth="toAlertWidth" :objHeight="toAlertHeight" :objWidth="toAlertWidth"></alertmsg>
  </div>
</template>
<script type="text/ecmascript-6">
  import register from '@/components/register/register'
  import alertmsg from '@/components/alertmsg/alertmsg'
  import {urlParse,urlSite,removeClassName} from '@/common/js/request';
  const mobileRed = /^1\d{10}$/;
  function errMsg(createElement,item){
      return createElement('p',{
        'class': 'm-des mt370 pl32 pr32'
      },
      item.map(function (data) {
        return createElement('i',data.error)
      })
      )
  }
  function conBn(createElement,item){
    return createElement('div',{
      'class': 'm-con m-bn mt336'
    },
    item.map(function(data){
      return createElement('a',{
        attrs:{
            'href':'javascript:;',
            'class':'c_fd5600 gainbn'
        },
        on:{
            click:function(){
                let oEnv = document.getElementById('env').value;
                if(oEnv == 'productiona')
                {
                  window.location.href='http://m.jinhui365.com/helps/downloadApp';
                }else{
                  window.location.href='http://m.jinhui365.cn/helps/downloadApp';
                }
            }
        }
      },data.con)
    })
    )
  }
  function indexErr(createElement,item){
    return createElement('div',{
      'class': 'm-con'
    }
    ,[
        errMsg(createElement,item),
        conBn(createElement,item)
    ])
  }
  const MyComponent = {
    props: ['item'],
    data(){
      return{
      }
    },
    render: function (createElement) {
//      debugger;
      return createElement('div',
        [indexErr(createElement,this.item)]
      )
    }
  };
  export default {
    data () {
          return {
            offsetHeight:'',
            offsetWidth:'',
            alertIsShow:false,
            oMobileVal: '',
            oMobileError: '',
            isClick:1,
            getUrlData:{
              random:(()=>{
                  let queryParam = urlParse();
                  return queryParam.random?queryParam.random:'';
              })()
            },
            show:false,
            currentView: MyComponent,
            special: [
              {
                "con": "查看其他活动",
                "error": ''
              }
            ]
          }
      },
    methods: {
      toAlertHeight: function(height) { // mychlid事件触发调用的方法
          this.offsetHeight = height; // massage就是子组件穿过来的内容
      },
      toAlertWidth: function(width) { // mychlid事件触发调用的方法
          this.offsetWidth = width; // massage就是子组件穿过来的内容
      },
      mobileBlur () {
        if (this.oMobileVal == '') {
          this.oMobileError = '*请输入手机号码';
          return false;
        } else if (!(mobileRed.test(this.oMobileVal))) {
          this.oMobileError = '*输入错误，请输入11位手机号码';
          return false;
        } else {
          this.oMobileError = '';
        }
      },
      mobileFocus () {
        this.oMobileError = '';
      },
      gain(){
          this.mobileBlur();
          if(this.oMobileError != '')
          {
              return false;
          }else{
              if(this.isClick)
              {
                this.isClick = 0;
              }else{
                  return false;
              }
            let params = {
                random:this.getUrlData.random,
                mobile:this.oMobileVal
            };
            this.$http.post('/redPacket/api.php?action=checkShare',params,{
                  emulateJSON:true
              }).then(function (res) {
                let data = res.data;
                console.log(data);
                if(data.message.code == 0)
                {
                  this.$refs.index1.style.display = 'none';
                  let oReg = document.getElementById('m-reg');
                  removeClassName(oReg,'m-reg');
                  this.isClick = 1;
                }else {
                    this.$refs.index1.style.display = 'none';
                    this.show = true;
                    this.special[0].error = data.message.message;
                }
              })
          }
      },
      friendForward()
      {
        let msgCon = '<div class="medal_gg"><div class="medal_bg1"><img src="static/new_share.png"></div></div>';
        this.$refs.alertmsg.alertMsgSuper(msgCon);
        this.alertShow();
      },
      alertShow(){
        let oBox = document.getElementById('alertBox');
        console.log(oBox)
        if(oBox)
        {
          oBox.onclick = ()=>{
            if(oBox.parentNode.style.display != 'none'){
              oBox.parentNode.style.display = 'none'
            }
            this.alertIsShow = false;
          }
        }
      },
      rule(){
        let msgCont = '<div class="m-cont-msgm">\
                      <div class="m-cont-rule">\
                      <div class="rule">活动规则</div>\
                      <p class="mt34">1、活动时间：截止至。</p>\
                      <p>2、活动期间，成功购买产品即有概率获分享红包，每个分享红包可领取五次。</p>\
                      <p>3、红包在新用户成功注册后自动发放，先到先得，领完即止。</p>\
                      <p>4、领取红包后，可前往APP“我的”-“我的红包”，官网“我的账户”-“我的红包”中查看。</p>\
                      <p>5、本次活动最终解释权归金汇金融所有，如有疑问请在线联系客户或拨打4006-999-133。</p>\
                      <p>6、通过本次活动邀请客户可与其他活动（如有）叠加计算。</p>\
                      <p>7、本次活动与苹果公司无关。</p>\
                      <div class="m-bn mt38 mb32"><a href="javascript:;" class="c_fd5600 gainbn" id="gainbn">关闭</a></div>\
                      </div></div>';
        this.$refs.alertmsg.alertMsgSuper(msgCont);
      }
    },
//    watch:{
//      offsetHeight:this.toAlertHeight
//    },
    mounted(){
//      this.$refs.alertmsg.addEventListener('myHeight', this.toAlertHeight);
    },
    components: {
      register,
      alertmsg
    }
  }
</script>
<style>
  .m-fans {width:100%; height:22.625rem;background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_bright.png) no-repeat; background-size: 100% 22.625rem;position:absolute;top:5rem;left:0;}
  .m-con {width:100%; text-align: center;}
  .m-home span {display:inline-block;}
  .m-gain {position:relative; margin-top: 0.3125rem; width:19.65625rem;height:8.3125rem; background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_msg.png) no-repeat; background-size: 19.65625rem 8.3125rem;}
  .m-des {font-size: 1.0625rem; color:#fff;}
  .m-money {width:8.4375rem; height:7.5rem; margin-top: 0.3125rem; background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_money.png) no-repeat; background-size: 8.4375rem 7.5rem; display:block;}
  .m-verify {width:100%; padding:0 1.9375rem; box-sizing: border-box;}
  .m-verify input {float:left; background:#fff;/* height:3.5rem; */line-height: 1.4rem; padding:1.05rem 0 1.05rem 1.75rem;  border-radius: 0.3125rem;box-sizing: border-box; font-size: 0.875rem;}
  .m-verify input.whole{width:100%;}
  .m-verify input.prev{width:56%;}
  .m-base {position:relative;}
  .m-base span {position:absolute; right:-1.0625rem; top:-6.25rem; width:6.53125rem; height:6.25rem; background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_person.png) no-repeat; background-size: 6.53125rem 6.25rem;}
  .m-bn {position:relative;}
  .m-bn a {width:10.875rem; height:2.75rem; line-height: 2.5rem; background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_icon.png) no-repeat; background-size: 10.875rem 6.5rem; display:inline-block;font-size: 0.875rem;}
  .m-bn a.gainbn {background-position: 0 0; }
  .m-bn a.seebn {background-position: 0 -3.75rem;}
  .m-frid {font-size: 0.625rem; color:#fff445; margin-top: 1.125rem;text-align: center;}
  .m-foot {font-size: 0.625rem; color:#ffe19f; margin-top: 2.4375rem;text-align: center;}
  .imgkap{float:right;width:42%; height:3.5rem; border-radius: 0.3125rem;}
  .m-verify input.next {float:right;width:42%;padding:0;height:3.5rem; line-height: 3.5rem; color:#f85e38; background:#fff445;}
  .m-gain1 {margin-top: 3.3125rem; display:block;width:11.4375rem; height:2.75rem; background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_suc.png) no-repeat; background-size: 11.4375rem 2.75rem; margin-left: auto; margin-right: auto;}
  .m-bn .packets {display:block;width:10.0rem; height:9.5rem; background:url(https://alicdn.jinhui365.com/activity/redPacket/images/new_sucper.png) no-repeat 0.4rem center; background-size: 10.0rem 9.5rem;margin:0 auto;}
  .xs_error {float:left;width:100%; font-size: 0.625rem;color:#fff;text-align: left;padding-left: 1.75rem; box-sizing: border-box;height:1.5rem; line-height: 1.5rem;}
  .m-reg {display:none;}
  .medal_gg {position:fixed; top:1.6875rem; right:1.25rem; width:13.96875rem; height:11.0625rem;z-index: 10;}
  .medal_bg1 img {display:inline-block; width:100%;}
</style>
